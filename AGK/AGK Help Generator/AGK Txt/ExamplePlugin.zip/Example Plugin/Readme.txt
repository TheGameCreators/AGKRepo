This is the source code to create a Tier 1 plugin using C++ on Linux (64-bit only), Mac (64-bit only), and Windows (32-bit and 64-bit). For more information see http://appgamekit.com/documentation/guides/14_plugins.htm

The code in this folder does not require any of the Tier 2 files to work.